package com.ium.example.myparsingapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private TextView mFajr, mDhuhr, mAsr, mMaghrib, mIsha;
    private RequestQueue mQueue;
    private TextClock txtclock;
    private EditText search_city;
    private String citta, myFajr, myDhuhr, myAsr, myMaghrib, myIsha;
    private Switch Fajr_Switch, Dhuhr_Switch, Asr_Switch, Maghrib_Switch, Isha_Switch;
    private ProgressDialog pg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        createNotificationChannel();
        mFajr = findViewById(R.id.fajr_p);
        mDhuhr = findViewById(R.id.dhuhr_p);
        mAsr = findViewById(R.id.asr_p);
        mMaghrib = findViewById(R.id.maghrib_p);
        mIsha = findViewById(R.id.isha_p);
        txtclock = findViewById(R.id.txtclock);
        search_city = findViewById(R.id.searchCity);
        Button buttonParse = findViewById(R.id.button_parse);
        Fajr_Switch = findViewById(R.id.switch1);
        Dhuhr_Switch = findViewById(R.id.switch2);
        Asr_Switch = findViewById(R.id.switch3);
        Maghrib_Switch = findViewById(R.id.switch4);
        Isha_Switch = findViewById(R.id.switch5);
        Fajr_Switch.setChecked(false);
        Dhuhr_Switch.setChecked(false);
        Asr_Switch.setChecked(false);
        Maghrib_Switch.setChecked(false);
        Isha_Switch.setChecked(false);
        mQueue = Volley.newRequestQueue(this);
        Date mydate = new Date();
        Calendar cal_alarm = Calendar.getInstance();
        Calendar cal_now = Calendar.getInstance();
        buttonParse.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String status_switch1;
                    citta = search_city.getText().toString();
                    System.out.println("Citta detected is = "+citta);
                    /*pg = new ProgressDialog(MainActivity.this);
                    pg.setTitle("Prayer App");
                    pg.setMessage("Please wait...");
                    pg.show();*/
                    citta = citta.toLowerCase();
                    jsonParse(citta);
                    //
                    //Only after the click I can check the status of the notify checker.
                }
        });
        //Time in log output
        Log.d("Time : ", txtclock.getText().toString());
        Fajr_Switch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // do something, the isChecked will be
                // true if the switch is in the On position
                if (Fajr_Switch.isChecked()) {
                    /* Setto il calendario alla date e all'orario corrente */
                    cal_now.setTime(mydate);
                    cal_alarm.setTime(mydate);
                    /* Toast per printare lo switch del Fajr :) */
                    Toast.makeText(MainActivity.this, "NOTIFICATION TOGGLE IS ON!", Toast.LENGTH_SHORT).show();
                    Log.d("Time in Fajr Prayer : ", myFajr.toString());
                    /* Make Intent e PendingIntent */
                    Intent i = new Intent(MainActivity.this, Reminder.class);
                    PendingIntent pi = PendingIntent.getBroadcast(MainActivity.this, 0, i, 0);
                    AlarmManager aM = (AlarmManager) getSystemService(ALARM_SERVICE);
                    //Split Fajr string into two halfs!
                    String fajr[] = myFajr.split(":");
                    int hh = Integer.parseInt(fajr[0]);
                    int mm = Integer.parseInt(fajr[1]);
                    System.out.println(hh + " : " + mm);
                    //Setting cal_alarm with the exact time retreived from JSON
                    cal_alarm.set(Calendar.HOUR_OF_DAY, hh);
                    cal_alarm.set(Calendar.MINUTE, mm);
                    cal_alarm.set(Calendar.SECOND, 0);
                    if(!cal_alarm.before(cal_now)){
                        //if the time is before the alarm_now then set it at this day if not, the next.
                        // This will be repeated for all other prayers, in'sha'Allah :)
                        Toast.makeText(MainActivity.this, "Fajr Alarm set for  today at " + hh + ":" + mm, Toast.LENGTH_LONG).show();
                        aM.set(AlarmManager.RTC_WAKEUP, cal_alarm.getTimeInMillis(), pi);
                    }
                } else {
                        Toast.makeText(MainActivity.this, "NOTIFICATION TOGGLE IS OFF!", Toast.LENGTH_SHORT).show();
                    }
                }
        });

        Dhuhr_Switch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(Dhuhr_Switch.isChecked()){
                    /* Setto il calendario alla date e all'orario corrente */
                    cal_now.setTime(mydate);
                    cal_alarm.setTime(mydate);
                    /* Toast per printare lo switch del Fajr :) */
                    Toast.makeText(MainActivity.this, "NOTIFICATION TOGGLE IS ON!", Toast.LENGTH_SHORT).show();
                    Log.d("Time in Dhuhr Prayer : ", myFajr.toString());
                    /* Make Intent e PendingIntent */
                    Intent i = new Intent(MainActivity.this, Reminder.class);
                    PendingIntent pi = PendingIntent.getBroadcast(MainActivity.this, 0, i, 0);
                    AlarmManager aM = (AlarmManager) getSystemService(ALARM_SERVICE);
                    //Split Fajr string into two halfs!
                    String dhr[] = myDhuhr.split(":");
                    int hh = Integer.parseInt(dhr[0]);
                    int mm = Integer.parseInt(dhr[1]);
                    System.out.println(hh + " : " + mm);
                    //Setting cal_alarm with the exact time retreived from JSON
                    cal_alarm.set(Calendar.HOUR_OF_DAY, hh);
                    cal_alarm.set(Calendar.MINUTE, mm);
                    cal_alarm.set(Calendar.SECOND, 0);
                    if(!cal_alarm.before(cal_now)){
                        //if the time is before the alarm_now then set it at this day if not, the next.
                        // This will be repeated for all other prayers, in'sha'Allah :)
                        Toast.makeText(MainActivity.this, "Dhuhr Alarm set for  today at " + hh + ":" + mm, Toast.LENGTH_LONG).show();
                        aM.set(AlarmManager.RTC_WAKEUP, cal_alarm.getTimeInMillis(), pi);
                    }
                } else {
                    Toast.makeText(MainActivity.this, "NOTIFICATION TOGGLE IS OFF!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        Asr_Switch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(Asr_Switch.isChecked()){
                    /* Setto il calendario alla date e all'orario corrente */
                    cal_now.setTime(mydate);
                    cal_alarm.setTime(mydate);
                    /* Toast per printare lo switch del Fajr :) */
                    Toast.makeText(MainActivity.this, "NOTIFICATION TOGGLE IS ON!", Toast.LENGTH_SHORT).show();
                    Log.d("Time in Asr Prayer : ", myAsr.toString());
                    /* Make Intent e PendingIntent */
                    Intent i = new Intent(MainActivity.this, Reminder.class);
                    PendingIntent pi = PendingIntent.getBroadcast(MainActivity.this, 0, i, 0);
                    AlarmManager aM = (AlarmManager) getSystemService(ALARM_SERVICE);
                    //Split Fajr string into two halfs!
                    String asr[] = myAsr.split(":");
                    int hh = Integer.parseInt(asr[0]);
                    int mm = Integer.parseInt(asr[1]);
                    System.out.println(hh + " : " + mm);
                    //Setting cal_alarm with the exact time retreived from JSON
                    cal_alarm.set(Calendar.HOUR_OF_DAY, hh);
                    cal_alarm.set(Calendar.MINUTE, mm);
                    cal_alarm.set(Calendar.SECOND, 0);
                    if(!cal_alarm.before(cal_now)){
                        //if the time is before the alarm_now then set it at this day if not, the next.
                        // This will be repeated for all other prayers, in'sha'Allah :)
                        Toast.makeText(MainActivity.this, "Asr Alarm set for  today at " + hh + ":" + mm, Toast.LENGTH_LONG).show();
                        aM.set(AlarmManager.RTC_WAKEUP, cal_alarm.getTimeInMillis(), pi);
                    }
                } else {
                    Toast.makeText(MainActivity.this, "NOTIFICATION TOGGLE IS OFF!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        Maghrib_Switch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(Maghrib_Switch.isChecked()){
                    /* Setto il calendario alla date e all'orario corrente */
                    cal_now.setTime(mydate);
                    cal_alarm.setTime(mydate);
                    /* Toast per printare lo switch del Fajr :) */
                    Toast.makeText(MainActivity.this, "NOTIFICATION TOGGLE IS ON!", Toast.LENGTH_SHORT).show();
                    Log.d("Time in Maghrib Prayer : ", myMaghrib.toString());
                    /* Make Intent e PendingIntent */
                    Intent i = new Intent(MainActivity.this, Reminder.class);
                    PendingIntent pi = PendingIntent.getBroadcast(MainActivity.this, 0, i, 0);
                    AlarmManager aM = (AlarmManager) getSystemService(ALARM_SERVICE);
                    //Split Fajr string into two halfs!
                    String magr[] = myMaghrib.split(":");
                    int hh = Integer.parseInt(magr[0]);
                    int mm = Integer.parseInt(magr[1]);
                    System.out.println(hh + " : " + mm);
                    //Setting cal_alarm with the exact time retreived from JSON
                    cal_alarm.set(Calendar.HOUR_OF_DAY, hh);
                    cal_alarm.set(Calendar.MINUTE, mm);
                    cal_alarm.set(Calendar.SECOND, 0);
                    if(!cal_alarm.before(cal_now)){
                        //if the time is before the alarm_now then set it at this day if not, the next.
                        // This will be repeated for all other prayers, in'sha'Allah :)
                        Toast.makeText(MainActivity.this, "Maghrib Alarm set for  today at " + hh + ":" + mm, Toast.LENGTH_LONG).show();
                        aM.set(AlarmManager.RTC_WAKEUP, cal_alarm.getTimeInMillis(), pi);
                    }
                }else {
                    Toast.makeText(MainActivity.this, "NOTIFICATION TOGGLE IS OFF!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        Isha_Switch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(Isha_Switch.isChecked()){
                    /* Setto il calendario alla date e all'orario corrente */
                    cal_now.setTime(mydate);
                    cal_alarm.setTime(mydate);
                    /* Toast per printare lo switch del Fajr :) */
                    Toast.makeText(MainActivity.this, "NOTIFICATION TOGGLE IS ON!", Toast.LENGTH_SHORT).show();
                    Log.d("Time in Isha Prayer : ", myIsha.toString());
                    /* Make Intent e PendingIntent */
                    Intent i = new Intent(MainActivity.this, Reminder.class);
                    PendingIntent pi = PendingIntent.getBroadcast(MainActivity.this, 0, i, 0);
                    AlarmManager aM = (AlarmManager) getSystemService(ALARM_SERVICE);
                    //Split Fajr string into two halfs!
                    String ish[] = myIsha.split(":");
                    int hh = Integer.parseInt(ish[0]);
                    int mm = Integer.parseInt(ish[1]);
                    System.out.println(hh + " : " + mm);
                    //Setting cal_alarm with the exact time retreived from JSON
                    cal_alarm.set(Calendar.HOUR_OF_DAY, hh);
                    cal_alarm.set(Calendar.MINUTE, mm);
                    cal_alarm.set(Calendar.SECOND, 0);
                    if(!cal_alarm.before(cal_now)){
                        //if the time is before the alarm_now then set it at this day if not, the next.
                        // This will be repeated for all other prayers, in'sha'Allah :)
                        Toast.makeText(MainActivity.this, "Isha Alarm set for  today at " + hh + ":" + mm, Toast.LENGTH_LONG).show();
                        aM.set(AlarmManager.RTC_WAKEUP, cal_alarm.getTimeInMillis(), pi);
                    }
                } else {
                    Toast.makeText(MainActivity.this, "NOTIFICATION TOGGLE IS OFF!", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    private void createNotificationChannel(){
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            CharSequence name = "studentChannel";
            String description = "Channel for prayers notification!";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel notificationChannel = new NotificationChannel("app", name, importance);
            notificationChannel.setDescription(description);

            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(notificationChannel);
        }
    }

    private void jsonParse(String citta) {
        String url = "";
        if(!citta.equals("null")) {
            url = "https://dailyprayer.abdulrcs.repl.co/api/"+citta;
        }

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            //pg.dismiss();
                            JSONObject resp = response.getJSONObject("today");
                            System.out.println("Oggetto : "+resp);
                            myFajr = resp.getString("Fajr");
                            myDhuhr = resp.getString("Dhuhr");
                            myAsr = resp.getString("Asr");
                            myMaghrib = resp.getString("Maghrib");
                            myIsha = resp.getString("Isha'a");
                            mFajr.setText(myFajr);
                            mDhuhr.setText(myDhuhr);
                            mAsr.setText(myAsr);
                            mMaghrib.setText(myMaghrib);
                            mIsha.setText(myIsha);
                        }
                        catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        mQueue.add(request);
    }
}